import { Router, type IRouter } from "express";
import {
  CompleteMonitoringSessionParams,
  CompleteMonitoringSessionResponse,
  CreateMonitoringEventBody,
  CreateMonitoringEventParams,
  CreateMonitoringEventResponse,
  CreateMonitoringSessionBody,
  CreateMonitoringSessionResponse,
  GetMonitoringOverviewResponse,
  ListMonitoringEventsQueryParams,
  ListMonitoringEventsResponse,
} from "@workspace/api-zod";

type Candidate = {
  name: string;
  age: number;
  semester: string;
  exam: string;
};

type MonitoringSession = {
  id: string;
  candidate: Candidate;
  source: "browser" | "mobile";
  status: "live" | "complete";
  startedAt: string;
  endedAt: string | null;
};

type MonitoringEvent = {
  id: string;
  sessionId: string;
  type: "face" | "gaze" | "person" | "object" | "camera" | "system";
  severity: "info" | "warning" | "critical";
  message: string;
  confidence: number;
  createdAt: string;
};

const router: IRouter = Router();
const defaultCandidate: Candidate = {
  name: "GURU",
  age: 24,
  semester: "7th",
  exam: "Advanced Web Systems",
};

let activeSession: MonitoringSession | null = null;
let events: MonitoringEvent[] = [
  {
    id: "evt-ready",
    sessionId: "preflight",
    type: "system",
    severity: "info",
    message: "Monitoring workspace ready for a new session",
    confidence: 100,
    createdAt: new Date().toISOString(),
  },
  {
    id: "evt-provider",
    sessionId: "preflight",
    type: "system",
    severity: "info",
    message: "Gravity AI adapter in standby; browser signals remain available",
    confidence: 99,
    createdAt: new Date(Date.now() - 45_000).toISOString(),
  },
];

function overview() {
  const elapsedSeconds = activeSession
    ? Math.max(
        0,
        Math.floor((Date.now() - Date.parse(activeSession.startedAt)) / 1000),
      )
    : 0;

  return GetMonitoringOverviewResponse.parse({
    candidate: activeSession?.candidate ?? defaultCandidate,
    sessionStatus: activeSession?.status === "live" ? "live" : "ready",
    provider: "Gravity AI",
    providerStatus: "standby",
    overallConfidence: activeSession?.status === "live" ? 96 : 0,
    elapsedSeconds,
    signals: activeSession?.status === "live"
      ? [
      {
        key: "face",
        label: "Face presence",
        status: "clear",
        confidence: 98,
        detail: "One face centered in frame",
      },
      {
        key: "gaze",
        label: "Gaze direction",
        status: "clear",
        confidence: 94,
        detail: "Looking toward the screen",
      },
      {
        key: "people",
        label: "Additional people",
        status: "clear",
        confidence: 99,
        detail: "No additional people detected",
      },
      {
        key: "objects",
        label: "Object scan",
        status: "clear",
        confidence: 92,
        detail: "No restricted objects detected",
      },
      ]
      : [
          {
            key: "face",
            label: "Face presence",
            status: "pending",
            confidence: 0,
            detail: "Waiting for camera feed",
          },
          {
            key: "gaze",
            label: "Gaze direction",
            status: "pending",
            confidence: 0,
            detail: "Waiting for camera feed",
          },
          {
            key: "people",
            label: "Additional people",
            status: "pending",
            confidence: 0,
            detail: "Waiting for camera feed",
          },
          {
            key: "objects",
            label: "Object scan",
            status: "pending",
            confidence: 0,
            detail: "Waiting for camera feed",
          },
        ],
  });
}

router.get("/monitoring/overview", (_req, res) => {
  res.json(overview());
});

router.get("/monitoring/events", (req, res) => {
  const parsed = ListMonitoringEventsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = events
    .slice()
    .sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt))
    .slice(0, parsed.data.limit);
  res.json(ListMonitoringEventsResponse.parse(data));
});

router.post("/monitoring/sessions", (req, res) => {
  const parsed = CreateMonitoringSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const session: MonitoringSession = {
    id: `session-${Date.now()}`,
    candidate: parsed.data.candidate,
    source: parsed.data.source,
    status: "live",
    startedAt: new Date().toISOString(),
    endedAt: null,
  };
  activeSession = session;
  events = [
    {
      id: `evt-${Date.now()}`,
      sessionId: session.id,
      type: "camera",
      severity: "info",
      message: `${session.source === "mobile" ? "Mobile" : "Browser"} camera session started`,
      confidence: 100,
      createdAt: new Date().toISOString(),
    },
    ...events,
  ];

  res.status(201).json(CreateMonitoringSessionResponse.parse(session));
});

router.post("/monitoring/sessions/:sessionId/events", (req, res) => {
  const params = CreateMonitoringEventParams.safeParse(req.params);
  const parsed = CreateMonitoringEventBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!activeSession || activeSession.id !== params.data.sessionId) {
    res.status(404).json({ error: "Monitoring session not found" });
    return;
  }

  const event: MonitoringEvent = {
    id: `evt-${Date.now()}`,
    sessionId: params.data.sessionId,
    ...parsed.data,
    createdAt: new Date().toISOString(),
  };
  events = [event, ...events].slice(0, 100);
  res.status(201).json(CreateMonitoringEventResponse.parse(event));
});

router.post("/monitoring/sessions/:sessionId/complete", (req, res) => {
  const params = CompleteMonitoringSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!activeSession || activeSession.id !== params.data.sessionId) {
    res.status(404).json({ error: "Monitoring session not found" });
    return;
  }

  activeSession = {
    ...activeSession,
    status: "complete",
    endedAt: new Date().toISOString(),
  };
  res.json(CompleteMonitoringSessionResponse.parse(activeSession));
});

export default router;