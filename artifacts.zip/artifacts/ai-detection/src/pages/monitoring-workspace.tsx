import { useCallback, useEffect, useMemo, useRef, useState, type RefObject } from 'react';
import {
  Activity,
  AlertCircle,
  BadgeCheck,
  Camera,
  CameraOff,
  CircleHelp,
  Clock3,
  Eye,
  FileWarning,
  LockKeyhole,
  MoreHorizontal,
  Pause,
  Play,
  Radio,
  RefreshCw,
  ScanFace,
  ShieldCheck,
  Square,
  UsersRound,
  Video,
  Wifi,
  Zap,
} from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import {
  getGetMonitoringOverviewQueryKey,
  getHealthCheckQueryKey,
  getListMonitoringEventsQueryKey,
  useCompleteMonitoringSession,
  useCreateMonitoringEvent,
  useCreateMonitoringSession,
  useGetMonitoringOverview,
  useHealthCheck,
  useListMonitoringEvents,
  type DetectionSignal,
  type MonitoringEvent,
  type MonitoringEventInput,
  type MonitoringOverview,
} from '@workspace/api-client-react';

const fallbackCandidate = {
  name: 'Guru',
  age: 24,
  semester: '7th',
  exam: 'Advanced Algorithms',
};

const fallbackOverview: MonitoringOverview = {
  candidate: fallbackCandidate,
  sessionStatus: 'ready',
  provider: 'Gravity AI',
  providerStatus: 'unavailable',
  overallConfidence: 0,
  elapsedSeconds: 0,
  signals: [],
};

const fallbackSignals: DetectionSignal[] = [
  { key: 'face', label: 'Face presence', status: 'pending', confidence: 0, detail: 'Waiting for camera feed' },
  { key: 'gaze', label: 'Gaze / head turn', status: 'pending', confidence: 0, detail: 'Waiting for camera feed' },
  { key: 'person', label: 'Extra people', status: 'pending', confidence: 0, detail: 'Waiting for camera feed' },
  { key: 'object', label: 'Restricted objects', status: 'pending', confidence: 0, detail: 'Waiting for camera feed' },
];

const signalIcons: Record<string, typeof ScanFace> = {
  face: ScanFace,
  gaze: Eye,
  person: UsersRound,
  object: FileWarning,
};

const eventIcons: Record<string, typeof Activity> = {
  face: ScanFace,
  gaze: Eye,
  person: UsersRound,
  object: FileWarning,
  camera: Camera,
  system: Activity,
};

const statusStyles = {
  clear: { label: 'Clear', dot: 'bg-[#81c342]', text: 'text-[#487d19]', soft: 'bg-[#edf6e6]', border: 'border-[#d5e9c4]' },
  warning: { label: 'Review', dot: 'bg-[#e3a51e]', text: 'text-[#9a6810]', soft: 'bg-[#fff7e5]', border: 'border-[#f1deb1]' },
  critical: { label: 'Critical', dot: 'bg-[#cc5049]', text: 'text-[#a13631]', soft: 'bg-[#fff0ef]', border: 'border-[#f0c8c5]' },
  pending: { label: 'Pending', dot: 'bg-[#a1acb9]', text: 'text-[#6c7784]', soft: 'bg-[#f1f4f7]', border: 'border-[#e1e6eb]' },
};

const providerStyles = {
  connected: { label: 'Connected', dot: 'bg-[#81c342]', text: 'text-[#487d19]' },
  standby: { label: 'Standby', dot: 'bg-[#e3a51e]', text: 'text-[#9a6810]' },
  unavailable: { label: 'Unavailable', dot: 'bg-[#cc5049]', text: 'text-[#a13631]' },
};

function formatElapsed(seconds: number) {
  const safe = Math.max(0, Math.floor(seconds));
  const minutes = Math.floor(safe / 60).toString().padStart(2, '0');
  const remainder = (safe % 60).toString().padStart(2, '0');
  return `${minutes}:${remainder}`;
}

function formatEventTime(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Just now';
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function statusForSignal(signal: DetectionSignal) {
  return statusStyles[signal.status] ?? statusStyles.pending;
}

function SectionLabel({ children, action }: { children: string; action?: string }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-3">
      <h2 className="font-mono text-[10px] font-medium uppercase tracking-[0.18em] text-[#758292]">{children}</h2>
      {action && <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-[#a1acb9]">{action}</span>}
    </div>
  );
}

function ConfidenceGauge({ value }: { value: number }) {
  const circumference = 2 * Math.PI * 48;
  const offset = circumference - (Math.min(100, Math.max(0, value)) / 100) * circumference;
  return (
    <div className="relative h-[138px] w-[138px]" data-testid="gauge-overall-confidence">
      <svg viewBox="0 0 112 112" className="h-full w-full -rotate-90">
        <circle cx="56" cy="56" r="48" fill="none" stroke="hsl(214 24% 91%)" strokeWidth="8" />
        <circle
          cx="56"
          cy="56"
          r="48"
          fill="none"
          stroke="hsl(73 75% 43%)"
          strokeLinecap="round"
          strokeWidth="8"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-[stroke-dashoffset] duration-700"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-mono text-[30px] font-medium leading-none text-[#1f2a39]" data-testid="text-overall-confidence">{value}%</span>
        <span className="mt-1 text-[10px] font-bold uppercase tracking-[0.12em] text-[#83909e]">confidence</span>
      </div>
    </div>
  );
}

function CameraFrame({
  videoRef,
  stream,
  cameraEnabled,
  recording,
  cameraError,
}: {
  videoRef: RefObject<HTMLVideoElement | null>;
  stream: MediaStream | null;
  cameraEnabled: boolean;
  recording: boolean;
  cameraError: string | null;
}) {
  return (
    <div className="relative aspect-[4/3] min-h-[280px] overflow-hidden rounded-[14px] bg-[#162433] shadow-[0_18px_45px_rgba(27,41,55,.16)]">
      <div className="absolute inset-0 mission-grid opacity-10" />
      {stream && cameraEnabled ? (
        <video ref={videoRef} autoPlay muted playsInline className="h-full w-full object-cover [transform:scaleX(-1)]" data-testid="video-camera-feed" />
      ) : (
        <div className="absolute inset-0 flex flex-col items-center justify-center px-8 text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-[#415267] bg-[#253548] text-[#c7d4de]">
            {cameraError ? <CameraOff size={24} strokeWidth={1.5} /> : <Camera size={24} strokeWidth={1.5} />}
          </div>
          <p className="text-sm font-semibold text-[#edf3f6]">{cameraError ? 'Camera access needs attention' : 'Camera feed is paused'}</p>
          <p className="mt-2 max-w-[250px] text-xs leading-5 text-[#9eafbd]">
            {cameraError ?? 'Enable the browser camera to begin visual monitoring.'}
          </p>
        </div>
      )}
      {stream && cameraEnabled && (
        <>
          <div className="pointer-events-none absolute inset-x-5 top-5 h-px bg-[#c6e888]/60 scan-line" />
          <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full border border-[#e7f7cb]/20 bg-[#15232f]/75 px-2.5 py-1.5 backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-[#c6e888] signal-pulse" />
            <span className="font-mono text-[10px] uppercase tracking-[0.13em] text-[#e7f7cb]">Live feed</span>
          </div>
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
            <span className="rounded bg-[#15232f]/75 px-2 py-1 font-mono text-[10px] text-[#c3d1dc] backdrop-blur">CAM-01 / 720P</span>
            {recording && <span className="flex items-center gap-1.5 rounded bg-[#15232f]/75 px-2 py-1 font-mono text-[10px] text-[#ffb9b3] backdrop-blur"><span className="h-1.5 w-1.5 rounded-full bg-[#ed6259] signal-pulse" /> REC</span>}
          </div>
        </>
      )}
    </div>
  );
}

function SignalRow({ signal, index }: { signal: DetectionSignal; index: number }) {
  const Icon = signalIcons[signal.key] ?? Activity;
  const style = statusForSignal(signal);
  return (
    <div className="group flex items-center gap-3 border-b border-[#e8edf1] py-3.5 last:border-0" data-testid={`row-signal-${signal.key}`}>
      <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${style.soft} ${style.text}`}>
        <Icon size={17} strokeWidth={1.8} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-[13px] font-bold text-[#2b3746]">{signal.label}</p>
          <span className={`shrink-0 font-mono text-[11px] font-medium ${style.text}`}>{signal.confidence}%</span>
        </div>
        <div className="mt-1.5 flex items-center gap-2">
          <div className="h-1 flex-1 overflow-hidden rounded-full bg-[#edf0f3]">
            <div className={`h-full rounded-full ${style.dot} transition-all duration-700`} style={{ width: `${Math.max(signal.confidence, index === 0 ? 2 : 0)}%` }} />
          </div>
          <span className={`flex items-center gap-1 text-[10px] font-bold uppercase tracking-[0.08em] ${style.text}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${style.dot}`} /> {style.label}
          </span>
        </div>
        <p className="mt-1 text-[11px] text-[#83909e]">{signal.detail}</p>
      </div>
    </div>
  );
}

function EventRow({ event }: { event: MonitoringEvent }) {
  const Icon = eventIcons[event.type] ?? Activity;
  const severityStyles = event.severity === 'critical'
    ? 'border-l-[#cc5049] bg-[#fff8f7]'
    : event.severity === 'warning'
      ? 'border-l-[#e3a51e] bg-[#fffdf7]'
      : 'border-l-[#c9d3dc] bg-[#fbfcfd]';
  return (
    <div className={`flex gap-3 border-b border-l-2 border-[#e8edf1] py-3 pl-3.5 pr-1 last:border-0 ${severityStyles}`} data-testid={`row-event-${event.id}`}>
      <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-[#edf1f4] text-[#627183]"><Icon size={14} strokeWidth={1.8} /></div>
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <p className="text-xs font-semibold leading-5 text-[#334152]">{event.message}</p>
          <span className="shrink-0 pt-0.5 font-mono text-[10px] text-[#96a1ad]">{formatEventTime(event.createdAt)}</span>
        </div>
        <div className="mt-1 flex items-center gap-2 text-[10px] uppercase tracking-[0.1em] text-[#8b98a5]">
          <span>{event.type}</span>
          <span className="h-0.5 w-0.5 rounded-full bg-[#b6c0c9]" />
          <span>{event.confidence}% match</span>
        </div>
      </div>
    </div>
  );
}

export default function MonitoringWorkspace() {
  const queryClient = useQueryClient();
  const overviewQuery = useGetMonitoringOverview({
    query: {
      queryKey: getGetMonitoringOverviewQueryKey(),
      refetchInterval: 10000,
    },
  });
  const eventsQuery = useListMonitoringEvents(
    { limit: 20 },
    { query: { queryKey: getListMonitoringEventsQueryKey({ limit: 20 }), refetchInterval: 10000 } },
  );
  const healthQuery = useHealthCheck({
    query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 15000 },
  });
  const createSession = useCreateMonitoringSession();
  const createEvent = useCreateMonitoringEvent();
  const completeSession = useCompleteMonitoringSession();

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recordingSupported, setRecordingSupported] = useState(true);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [localElapsed, setLocalElapsed] = useState(0);
  const [actionError, setActionError] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [source, setSource] = useState<'browser' | 'mobile'>('browser');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordingChunksRef = useRef<Blob[]>([]);

  const overview = overviewQuery.data ?? fallbackOverview;
  const signals = overview.signals.length > 0 ? overview.signals : fallbackSignals;
  const events = eventsQuery.data ?? [];
  const providerStatus = providerStyles[overview.providerStatus] ?? providerStyles.unavailable;
  const isLive = Boolean(sessionId) && !isPaused;
  const elapsed = isLive ? Math.max(overview.elapsedSeconds, localElapsed) : overview.elapsedSeconds || localElapsed;

  useEffect(() => {
    if (!stream || !videoRef.current) return;
    videoRef.current.srcObject = stream;
  }, [stream]);

  useEffect(() => {
    if (!isLive) return;
    const timer = window.setInterval(() => setLocalElapsed((current) => current + 1), 1000);
    return () => window.clearInterval(timer);
  }, [isLive]);

  useEffect(() => {
    return () => {
      recorderRef.current?.stop();
      stream?.getTracks().forEach((track) => track.stop());
    };
  }, [stream]);

  const recordEvent = useCallback((data: MonitoringEventInput, targetSessionId = sessionId) => {
    if (!targetSessionId) return;
    createEvent.mutate({ sessionId: targetSessionId, data }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMonitoringEventsQueryKey({ limit: 20 }) });
      },
    });
  }, [createEvent, queryClient, sessionId]);

  const enableCamera = async () => {
    setCameraError(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError('This browser does not expose camera access.');
      return null;
    }
    try {
      const nextStream = await navigator.mediaDevices.getUserMedia({ video: { width: 1280, height: 720, facingMode: 'user' }, audio: false });
      setStream(nextStream);
      setCameraEnabled(true);
      return nextStream;
    } catch (error) {
      const message = error instanceof DOMException && error.name === 'NotAllowedError'
        ? 'Camera permission was denied. Allow camera access in your browser settings to continue.'
        : 'Camera could not be started. Check that it is not being used by another application.';
      setCameraError(message);
      setActionError(message);
      return null;
    }
  };

  const handleStart = async () => {
    setActionError(null);
    const nextStream = stream ?? await enableCamera();
    if (!nextStream) return;
    createSession.mutate({
      data: { candidate: overview.candidate, source },
    }, {
      onSuccess: (session) => {
        setSessionId(session.id);
        setLocalElapsed(0);
        setIsPaused(false);
        queryClient.invalidateQueries({ queryKey: getGetMonitoringOverviewQueryKey() });
        recordEvent({ type: 'system', severity: 'info', message: 'Browser monitoring session started', confidence: 100 }, session.id);
      },
      onError: () => setActionError('The monitoring session could not be started. Try again.'),
    });
  };

  const handleRecording = () => {
    setActionError(null);
    if (!stream) {
      setActionError('Enable the camera before starting a recording.');
      return;
    }
    if (recording) {
      recorderRef.current?.stop();
      setRecording(false);
      recordEvent({ type: 'camera', severity: 'info', message: 'Recording paused by operator', confidence: 100 });
      return;
    }
    if (typeof MediaRecorder === 'undefined') {
      setRecordingSupported(false);
      setActionError('MediaRecorder is not supported in this browser.');
      return;
    }
    try {
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      recordingChunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) recordingChunksRef.current.push(event.data);
      };
      recorder.onstop = () => {
        const chunks = recordingChunksRef.current;
        if (chunks.length === 0) return;
        const recordingBlob = new Blob(chunks, { type: 'video/webm' });
        const downloadUrl = URL.createObjectURL(recordingBlob);
        const link = document.createElement('a');
        link.href = downloadUrl;
        link.download = `ai-detection-${overview.candidate.name.toLowerCase()}-${Date.now()}.webm`;
        link.click();
        window.setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
        recordingChunksRef.current = [];
      };
      recorder.start(1000);
      recorderRef.current = recorder;
      setRecording(true);
      recordEvent({ type: 'camera', severity: 'info', message: 'Recording started', confidence: 100 });
    } catch {
      setRecordingSupported(false);
      setActionError('Recording could not be started in this browser.');
    }
  };

  const handleCameraToggle = () => {
    if (!stream) {
      void enableCamera();
      return;
    }
    const nextEnabled = !cameraEnabled;
    stream.getVideoTracks().forEach((track) => { track.enabled = nextEnabled; });
    setCameraEnabled(nextEnabled);
    recordEvent({ type: 'camera', severity: nextEnabled ? 'info' : 'warning', message: nextEnabled ? 'Camera feed resumed' : 'Camera feed paused by operator', confidence: 100 });
  };

  const handleComplete = () => {
    if (!sessionId) return;
    completeSession.mutate({ sessionId }, {
      onSuccess: () => {
        recorderRef.current?.stop();
        setRecording(false);
        setIsPaused(true);
        setCameraEnabled(false);
        stream?.getTracks().forEach((track) => track.stop());
        queryClient.invalidateQueries({ queryKey: getGetMonitoringOverviewQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListMonitoringEventsQueryKey({ limit: 20 }) });
        setSessionId(null);
      },
      onError: () => setActionError('The session could not be completed. Keep the feed live and try again.'),
    });
  };

  const healthLabel = healthQuery.isLoading ? 'Checking API' : healthQuery.data?.status ?? (healthQuery.isError ? 'API unavailable' : 'API status unknown');
  const candidateInitial = overview.candidate.name.slice(0, 1).toUpperCase();
  const latestEvent = useMemo(() => events[0], [events]);
  const gazeSignal = signals.find((signal) => signal.key === 'gaze');

  return (
    <div className="min-h-[100dvh] bg-[#f2f5f7] text-[#243140]">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-[238px] flex-col bg-[#172536] text-[#b9c7d3] lg:flex">
        <div className="flex h-[78px] items-center border-b border-[#304153] px-6">
          <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-[9px] bg-[#c6e888] text-[#172536]"><ShieldCheck size={19} strokeWidth={2.4} /></div>
          <div>
            <p className="text-[13px] font-extrabold tracking-[0.12em] text-[#f0f5f4]">AI DETECTION</p>
            <p className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.18em] text-[#7f92a3]">Operator console</p>
          </div>
        </div>
        <div className="px-3 py-6">
          <p className="px-3 pb-2 font-mono text-[9px] uppercase tracking-[0.18em] text-[#718497]">Workspace</p>
          <button type="button" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex w-full items-center gap-3 rounded-lg bg-[#26394c] px-3 py-3 text-left text-[#eff5f4] shadow-[inset_3px_0_0_#c6e888]" data-testid="button-nav-monitoring">
            <Radio size={17} className="text-[#c6e888]" />
            <span className="text-xs font-bold">Live monitoring</span>
            <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#c6e888] signal-pulse" />
          </button>
          <div className="mt-2 flex items-center gap-3 rounded-lg px-3 py-3 text-[#718497]">
            <FileWarning size={17} />
            <span className="text-xs font-semibold">Evidence review</span>
            <span className="ml-auto font-mono text-[10px]">—</span>
          </div>
        </div>
        <div className="mt-auto border-t border-[#304153] px-6 py-5">
          <div className="flex items-center gap-2 text-[#89a0b1]"><LockKeyhole size={13} /><span className="font-mono text-[9px] uppercase tracking-[0.14em]">Secure workspace</span></div>
          <p className="mt-2 text-[10px] leading-4 text-[#718497]">Exam integrity operations<br />Browser monitoring source</p>
        </div>
      </aside>

      <main className="lg:pl-[238px]">
        <header className="sticky top-0 z-10 border-b border-[#dce3e8] bg-[#f2f5f7]/95 backdrop-blur-md">
          <div className="flex min-h-[78px] items-center justify-between gap-4 px-5 py-3 sm:px-8 xl:px-10">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[9px] bg-[#172536] text-[#c6e888] lg:hidden"><ShieldCheck size={18} /></div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-[#8794a1]">Session / {source}</span>
                  <span className="h-1 w-1 rounded-full bg-[#c1cbd3]" />
                  <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-[#8794a1]">Browser source</span>
                </div>
                <h1 className="mt-1 truncate text-lg font-extrabold tracking-[-0.03em] text-[#273544] sm:text-xl">Live monitoring</h1>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-3 sm:gap-5">
              <div className="hidden items-center gap-2 sm:flex"><span className={`h-1.5 w-1.5 rounded-full ${healthQuery.isError ? 'bg-[#cc5049]' : 'bg-[#81c342]'}`} /><span className="font-mono text-[10px] uppercase tracking-[0.1em] text-[#748291]" data-testid="status-api-health">{healthLabel}</span></div>
              <div className="hidden h-7 w-px bg-[#d9e0e5] sm:block" />
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#dceac7] text-xs font-extrabold text-[#4e741f]" data-testid="avatar-operator">OP</div>
              <span className="hidden text-xs font-bold text-[#465463] md:block">Operator</span>
              <button type="button" onClick={() => setActionError('No additional workspace actions are available in this console.')} className="flex h-8 w-8 items-center justify-center rounded-lg text-[#6c7a88] hover:bg-[#e5eaee]" aria-label="More workspace actions" data-testid="button-more-actions"><MoreHorizontal size={18} /></button>
            </div>
          </div>
        </header>

        <div className="relative overflow-hidden px-5 pb-10 pt-7 sm:px-8 xl:px-10">
          <div className="pointer-events-none absolute -right-24 -top-16 h-72 w-72 rounded-full bg-[#dfeec8]/35 blur-3xl" />
          <div className="relative mx-auto max-w-[1440px]">
            <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div className="reveal-up">
                <p className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-[#83909e]"><span className="h-1.5 w-1.5 rounded-full bg-[#81c342]" /> Active candidate</p>
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#dceac7] text-lg font-extrabold text-[#557725]" data-testid="avatar-candidate">{candidateInitial}</div>
                  <div>
                    <h2 className="text-[25px] font-extrabold tracking-[-0.04em] text-[#263443]" data-testid="text-candidate-name">{overview.candidate.name}</h2>
                    <p className="mt-0.5 text-xs text-[#768493]" data-testid="text-candidate-exam">{overview.candidate.exam} <span className="mx-1.5 text-[#b1bbc4]">/</span> Age {overview.candidate.age} <span className="mx-1.5 text-[#b1bbc4]">/</span> Semester {overview.candidate.semester}</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 reveal-up reveal-up-delay-1">
                <div className={`flex items-center gap-2 rounded-full border border-[#dce4e9] bg-white px-3 py-2 ${isLive ? 'text-[#4d7a20]' : 'text-[#7d8995]'}`} data-testid="status-session">
                  <span className={`h-1.5 w-1.5 rounded-full ${isLive ? 'bg-[#81c342] signal-pulse' : 'bg-[#aab5bf]'}`} />
                  <span className="font-mono text-[10px] font-medium uppercase tracking-[0.12em]">{isLive ? 'Monitoring live' : 'Ready to monitor'}</span>
                </div>
                {isLive && (
                  <button type="button" onClick={handleComplete} disabled={completeSession.isPending} className="flex items-center gap-2 rounded-lg border border-[#e1b3af] bg-[#fff9f8] px-3 py-2 text-xs font-bold text-[#a0443e] transition hover:bg-[#fff0ef] disabled:cursor-wait disabled:opacity-60" data-testid="button-complete-session">
                    <Square size={13} fill="currentColor" /> {completeSession.isPending ? 'Completing' : 'End session'}
                  </button>
                )}
              </div>
            </div>

            {(overviewQuery.isError || eventsQuery.isError || actionError) && (
              <div className="mb-5 flex flex-col gap-3 rounded-xl border border-[#f0c8c5] bg-[#fff5f4] px-4 py-3 text-sm text-[#963e39] sm:flex-row sm:items-center sm:justify-between" role="alert" data-testid="alert-monitoring-error">
                <div className="flex items-start gap-2"><AlertCircle size={17} className="mt-0.5 shrink-0" /><span>{actionError ?? 'Some monitoring data could not be loaded. Live controls remain available.'}</span></div>
                <button type="button" onClick={() => { void overviewQuery.refetch(); void eventsQuery.refetch(); }} className="flex items-center gap-2 self-start rounded-md border border-[#e4b8b4] px-2.5 py-1.5 text-xs font-bold hover:bg-[#ffebe9] sm:self-auto" data-testid="button-retry-monitoring"><RefreshCw size={13} /> Retry</button>
              </div>
            )}

            <div className="grid gap-5 xl:grid-cols-[minmax(0,1.45fr)_minmax(355px,.75fr)]">
              <section className="reveal-up reveal-up-delay-1 rounded-2xl border border-[#dce3e8] bg-white p-4 shadow-[0_7px_24px_rgba(37,53,68,.045)] sm:p-5">
                <div className="mb-4 flex items-center justify-between">
                  <SectionLabel action={cameraEnabled ? 'Camera / active' : 'Camera / offline'}>Visual feed</SectionLabel>
                  <div className="flex items-center gap-1.5 text-[#71808f]"><Wifi size={13} /><span className="font-mono text-[10px] uppercase tracking-[0.1em]">Encrypted stream</span></div>
                </div>
                <CameraFrame videoRef={videoRef} stream={stream} cameraEnabled={cameraEnabled} recording={recording} cameraError={cameraError} />
                <div className="mt-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
                  <div className="flex items-center gap-3">
                    <button type="button" onClick={handleCameraToggle} className={`flex items-center gap-2 rounded-lg px-3 py-2.5 text-xs font-bold transition ${cameraEnabled ? 'bg-[#edf6e6] text-[#4d7a20] hover:bg-[#e2f1d5]' : 'bg-[#172536] text-[#eff5f4] hover:bg-[#24384b]'}`} data-testid="button-toggle-camera">
                      {cameraEnabled ? <Camera size={15} /> : <CameraOff size={15} />} {cameraEnabled ? 'Camera on' : 'Enable camera'}
                    </button>
                    <button type="button" onClick={handleRecording} disabled={!recordingSupported || !sessionId} title={!sessionId ? 'Start a monitoring session first' : undefined} className={`flex items-center gap-2 rounded-lg border px-3 py-2.5 text-xs font-bold transition disabled:cursor-not-allowed disabled:opacity-50 ${recording ? 'border-[#edc4c0] bg-[#fff4f2] text-[#ac463f]' : 'border-[#dce3e8] bg-white text-[#566576] hover:bg-[#f5f7f8]'}`} data-testid="button-toggle-recording">
                      {recording ? <Pause size={15} /> : <Video size={15} />} {recording ? 'Pause recording' : 'Start recording'}
                    </button>
                  </div>
                  <div className="flex items-center gap-2 text-[#82909d]"><Clock3 size={14} /><span className="font-mono text-xs" data-testid="text-elapsed-time">{formatElapsed(elapsed)}</span><span className="text-[10px] uppercase tracking-[0.1em]">elapsed</span></div>
                </div>
                <div className="mt-4 flex items-center justify-between gap-3 rounded-lg border border-[#e8edf1] bg-[#f8fafb] px-3 py-2.5">
                  <div>
                    <p className="text-[11px] font-bold text-[#526171]">Capture source</p>
                    <p className="mt-0.5 text-[10px] text-[#8a97a4]">Choose the device profile for this session</p>
                  </div>
                  <div className="flex shrink-0 rounded-md border border-[#dce3e8] bg-white p-0.5">
                    {(['browser', 'mobile'] as const).map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => setSource(option)}
                        className={`rounded px-2.5 py-1.5 font-mono text-[10px] font-medium uppercase tracking-[0.08em] transition ${source === option ? 'bg-[#172536] text-[#eff5f4]' : 'text-[#7d8995] hover:bg-[#f2f5f7]'}`}
                        data-testid={`button-source-${option}`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
                {isLive && gazeSignal && gazeSignal.status !== 'clear' && (
                  <div className="mt-3 flex items-center gap-2 rounded-lg border border-[#f1deb1] bg-[#fff7e5] px-3 py-2.5 text-[11px] font-semibold text-[#9a6810]" data-testid="alert-gaze-signal">
                    <Eye size={14} />
                    {gazeSignal.detail}
                  </div>
                )}
                {isLive && gazeSignal?.status === 'clear' && (
                  <p className="mt-3 flex items-center gap-2 text-[10px] uppercase tracking-[0.08em] text-[#81909e]" data-testid="text-gaze-status">
                    <Eye size={13} className="text-[#81c342]" /> Head and gaze tracking active
                  </p>
                )}
                {!sessionId && (
                  <button type="button" onClick={handleStart} disabled={createSession.isPending} className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-[#b8d977] px-4 py-3 text-xs font-extrabold uppercase tracking-[0.12em] text-[#243516] shadow-[0_4px_0_#8fb353] transition hover:bg-[#c6e888] active:translate-y-px active:shadow-none disabled:cursor-wait disabled:opacity-60" data-testid="button-start-monitoring">
                    {createSession.isPending ? <RefreshCw size={15} className="animate-spin" /> : <Play size={15} fill="currentColor" />} {createSession.isPending ? 'Starting secure session' : 'Start monitoring session'}
                  </button>
                )}
                {cameraError && <p className="mt-3 flex items-start gap-2 text-[11px] leading-4 text-[#a0443e]" data-testid="text-camera-error"><CircleHelp size={14} className="mt-0.5 shrink-0" /> Browser permission is required for face, gaze, and object signals. No camera data leaves this page until a session is started.</p>}
              </section>

              <section className="reveal-up reveal-up-delay-2 rounded-2xl border border-[#dce3e8] bg-white p-5 shadow-[0_7px_24px_rgba(37,53,68,.045)]">
                <SectionLabel action="Live assessment">Detection confidence</SectionLabel>
                <div className="flex items-center gap-5 border-b border-[#e8edf1] pb-5">
                  <ConfidenceGauge value={overview.overallConfidence} />
                  <div className="min-w-0">
                    <div className="mb-2 flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-[#81c342] signal-pulse" /><span className="text-xs font-extrabold text-[#354354]">Signal quality</span></div>
                    <p className="text-[12px] leading-5 text-[#7c8997]">Composite confidence across active detection signals.</p>
                    <div className="mt-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.1em] text-[#94a0ab]"><Activity size={13} /> {signals.filter((signal) => signal.status === 'clear').length} of {signals.length} clear</div>
                  </div>
                </div>
                <div className="mt-1">
                  {signals.map((signal, index) => <SignalRow key={signal.key} signal={signal} index={index} />)}
                </div>
              </section>
            </div>

            <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1.1fr)_minmax(320px,.9fr)]">
              <section className="reveal-up reveal-up-delay-2 rounded-2xl border border-[#dce3e8] bg-white p-5 shadow-[0_7px_24px_rgba(37,53,68,.045)]">
                <div className="flex items-center justify-between">
                  <SectionLabel action={`${events.length} records`}>Evidence timeline</SectionLabel>
                  <button type="button" onClick={() => void eventsQuery.refetch()} className="mb-3 flex items-center gap-1.5 text-[#82909d] hover:text-[#4d7a20]" data-testid="button-refresh-events"><RefreshCw size={13} /> <span className="font-mono text-[10px] uppercase tracking-[0.1em]">Refresh</span></button>
                </div>
                <div className="max-h-[315px] overflow-y-auto pr-1">
                  {eventsQuery.isLoading ? (
                    <div className="space-y-3 py-2" data-testid="loading-events">{[1, 2, 3].map((item) => <div key={item} className="h-12 animate-pulse rounded-lg bg-[#f2f5f7]" />)}</div>
                  ) : events.length > 0 ? events.map((event) => <EventRow key={event.id} event={event} />) : (
                    <div className="flex flex-col items-center justify-center py-10 text-center" data-testid="empty-events">
                      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-full bg-[#f0f4f6] text-[#8c9aa6]"><Activity size={18} /></div>
                      <p className="text-xs font-bold text-[#526171]">No events recorded</p>
                      <p className="mt-1 max-w-[220px] text-[11px] leading-4 text-[#8c98a4]">Detection events will appear here once the session is live.</p>
                    </div>
                  )}
                </div>
                {latestEvent && <p className="mt-3 border-t border-[#edf0f2] pt-3 font-mono text-[10px] uppercase tracking-[0.1em] text-[#a1acb9]">Latest signal received at {formatEventTime(latestEvent.createdAt)}</p>}
              </section>

              <section className="reveal-up reveal-up-delay-3 rounded-2xl bg-[#172536] p-5 text-[#d6e0e6] shadow-[0_9px_28px_rgba(23,37,54,.13)]">
                <div className="mb-5 flex items-start justify-between">
                  <div><SectionLabel>Provider connection</SectionLabel><div className="flex items-center gap-2"><Zap size={17} className="text-[#c6e888]" /><h2 className="text-base font-extrabold text-[#f2f6f5]" data-testid="text-provider-name">{overview.provider}</h2></div></div>
                  <div className="flex items-center gap-2 rounded-full border border-[#405467] px-2.5 py-1.5" data-testid="status-provider">
                    <span className={`h-1.5 w-1.5 rounded-full ${providerStatus.dot}`} />
                    <span className={`font-mono text-[10px] uppercase tracking-[0.1em] ${providerStatus.text}`}>{providerStatus.label}</span>
                  </div>
                </div>
                <div className="border-t border-[#304355] pt-4">
                  <p className="text-[12px] leading-5 text-[#9eafbc]">{overview.providerStatus === 'connected' ? 'Gravity AI is returning live detection signals for this candidate.' : overview.providerStatus === 'standby' ? 'Gravity AI is available but not currently returning live signals.' : 'Gravity AI connection is not available. Detection results may be delayed or absent.'}</p>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <div className="rounded-lg border border-[#304355] bg-[#1d3042] px-3 py-2.5"><p className="font-mono text-[9px] uppercase tracking-[0.1em] text-[#7f94a5]">Transport</p><p className="mt-1 flex items-center gap-1.5 text-xs font-bold text-[#dce7e9]"><Wifi size={13} className={healthQuery.isError ? 'text-[#df7168]' : 'text-[#c6e888]'} /> {healthQuery.isError ? 'Degraded' : 'TLS / secure'}</p></div>
                    <div className="rounded-lg border border-[#304355] bg-[#1d3042] px-3 py-2.5"><p className="font-mono text-[9px] uppercase tracking-[0.1em] text-[#7f94a5]">Last check</p><p className="mt-1 text-xs font-bold text-[#dce7e9]">{healthQuery.isLoading ? 'Checking' : 'Just now'}</p></div>
                  </div>
                </div>
                <div className="mt-5 flex items-center gap-2 text-[10px] text-[#7f94a5]"><LockKeyhole size={13} /> Provider state is reported by the monitoring API</div>
              </section>
            </div>

            <footer className="mt-6 flex flex-col justify-between gap-2 border-t border-[#dce3e8] pt-4 text-[#9aa6b2] sm:flex-row">
              <div className="flex items-center gap-2"><BadgeCheck size={14} className="text-[#7fae43]" /><span className="font-mono text-[10px] uppercase tracking-[0.1em]">Evidence chain protected</span></div>
              <p className="font-mono text-[10px] uppercase tracking-[0.1em]">All times local / data retention policy applies</p>
            </footer>
          </div>
        </div>
      </main>
    </div>
  );
}